/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.

JMJE BAKKER 2016

TBC

- doolhof maakt soms NIET aansluitende routes?
- inname velden doolhof afmeting ipv 20x20 en op apart Frame doolhof tonen!
- class factory width interface


 */
package doolhofv1;

// import examples.Antenna;
import java.applet.Applet;
import java.awt.Color;
import java.awt.Event;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Label;
import java.awt.TextField;
import java.util.Vector;

import java.applet.* ;
import java.awt.* ;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.math.*;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.JFrame;



/**
 * <p>Title: <Doolhof/p>
 * <p>Description: <Doolhof generator/p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: FAMKO companie </p>
 * @author unascribed Koos Bakker 11-06-2003
 * @version 3.1
 * Aanvullingen:
 * inter-route ( poorten tussen routes )
 * file i/o routes
 * routecode richting controle
 *
 */


public class doolhofv1 extends JFrame {
    // windowgrootte
    
    int Windowwidth=800;
    int Windowheight=700;
    
    public Label l1 ;
    public TextField t1,t2;
public String get_ch = "leeg" ;
 
int x = 1 ;
Font mono, klein;
// int cel[][] ; // 2016
//public cell cell_array[][]; // 2016

public cell[][] cell_array = new cell[20][20];

public Vector route_codes = new Vector();
int i,j;

Color[] kleuren = {
Color.blue, Color.cyan, Color.lightGray,
Color.gray ,Color.magenta , Color.orange , Color.pink ,
Color.red , Color.yellow ,Color.green};

int x_off = 40;
int y_off = 60;

int width = 20;
int height = 20;   


int startX, startY; // Starting X and Y values of maze
int endX = width -1;
int endY = height -1;     // Ending X and Y values of maze

      
    public doolhofv1() {
        
        setSize(Windowwidth,Windowheight);
          setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
          setResizable(false);
          setLocationRelativeTo(null);
          setVisible(true);
          
          
          setBackground(Color.GRAY);
          setLayout(new FlowLayout() ) ;
          // setLayout(null);
          initialiseer();
          
    }
    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            javax.swing.UIManager.LookAndFeelInfo[] installedLookAndFeels=javax.swing.UIManager.getInstalledLookAndFeels();
            for (int idx=0; idx<installedLookAndFeels.length; idx++)
                if ("Nimbus".equals(installedLookAndFeels[idx].getName())) {
                    javax.swing.UIManager.setLookAndFeel(installedLookAndFeels[idx].getClassName());
                    break;
                }
            
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(doolhofv1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(doolhofv1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(doolhofv1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(doolhofv1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

            
        new doolhofv1();
       
    }



  // object cell
public  class cell {
  private int breedte;
  private int hoogte;
  private boolean used;
  private boolean correctpath;
  private String naam;
  private String route_code;
  private int route;
  private boolean noord;
  private boolean zuid;
  private boolean oost;
  private boolean west;
  private int x1;
  private int y1;
  private int x2;
  private int y2;
  private Color kleur;

    public cell()
    {
    breedte = 25;
    hoogte = 25;
    used = false ;
    correctpath = false;
    naam = "A";
    route_code = " A1" ;
    route = -1;
    noord = false;
    zuid = false ;
    oost = false ;
    west = false;
    x1 = 25 ;
    y1 = 25;
    x2 = x1 + breedte;
    y2 = y1 + hoogte;
    kleur = Color.red;
    }

    public cell ( int breedte, int hoogte, boolean used, boolean correctpath, String naam ,
    String route_code, int route, boolean noord, boolean zuid , boolean oost, boolean west, int x1, int y1, int x2, int y2, Color kleur )
    {
    this.breedte = breedte;
    this.hoogte = hoogte;
    this.used = used;
    this.correctpath = correctpath;
    this.naam = naam;
    this.route_code = route_code;
    this.route = route;
    this.noord = noord;
    this.zuid = zuid;
    this.oost = oost;
    this.west = west;
    this.x1 = x1;
    this.y1 = y1;
    this.x2 = x2;
    this.y2 = y2;
    this.kleur = Color.blue;
    }
  }

  public void initialiseer()
  {
      
      
  // presentie
  System.out.println("\n");
  System.out.println("@famk  Bakker 2003 edition v2016.1 (init)");
  System.out.println("\n");

  // positioneer de inname velden
  // setLayout( null) ;
  
  l1 = new Label("AANTAL GENERATIES" );
  t1 = new TextField(20);
  t2 = new TextField(20);
  
  // Niet bij flowLayout 2016
  // setLayout(new FlowLayout() ) ipv setLayout(null);
  //l1.setBounds(40, 530, 110, 20 );
  //t1.setBounds(160,530, 60, 20);
  //t2.setBounds(260,530, 60, 20);
  
  mono = new Font("Dialog", Font.CENTER_BASELINE , 10 );
  klein = new Font("Dialog", Font.CENTER_BASELINE , 5 );
  l1.setFont(mono);
  
  add (l1 );
  add (t1);
  add (t2);
  
  setBackground ( Color.black );
 

  // kolom is van boven naar beneden (Y) coordinaten = i
  // col is van links naar rechts = j
  
  for (i=0 ; i <= 19 ; i++ )
    {
    for (j=0 ; j <= 19 ; j++)
    {
        
    cell_array[j][i] = new cell ( 25 , 25 , false , false,  "BK" , "R " + i + " " + j, -1,  false, false, false, false, i*25 , j*25 , i*25 + 25, j*25 + 25 , Color.blue ) ;
    
    // for debug purpose wth
    // System.out.println("cell_array[" + i + ","+ j + "] = (" + i*25 + "," + j*25 + ")"  );
    }
    }
  }

  
  public boolean action(Event evt, Object arg) {
  int t;
  get_ch = t1.getText();

    try {
    x=Integer.parseInt(get_ch);
        }
    catch ( NumberFormatException nfe ){
        System.out.println("fout getal" );
        x=1;
        }
    t1.setText(get_ch);
    t1.selectAll();
    repaint();
  return true;
  }

  public String doolhof ()
    {
     
    int i,j;
    int i1,j1;
    boolean route_bestaat;
    int r;
    Color kleur;
    String code;
    
    // initialiseerialiseer eerst de array met doolhofcellen
    
    for (i=0 ; i <= 19 ; i++ )
      {
      for (j=0 ; j <= 19 ; j++)
        {
        cell_array[i][j].used = false;
        cell_array[i][j].kleur = Color.BLUE;
        cell_array[i][j].noord = false;
        cell_array[i][j].zuid = false;
        cell_array[i][j].oost = false;
        cell_array[i][j].west = false;
        cell_array[i][j].naam = "BK";
        cell_array[i][j].route_code = "R";
        }
      }

    // bepaal verschillende routes
    code =  "R" + (int) ( Math.random() * 100 );
    // kleur = random_kleur();
    
    for (i=0 ; i <= 19 ; i++ )
      {
      for (j=0 ; j <= 19 ; j++)
        {
        
            
        kleur = random_kleur();
        
        code =  "R" + (int) ( Math.random() * 100 );

        // aansluiting op bestaande kleur = route
        route_bestaat = false;
        for (i1=0 ; i1 < 19 ; i1++ )
          {
          for (j1=0 ; j1 < 19 ; j1++)
            {
            if ( cell_array[i1][j1].kleur == kleur )
              {
              route_bestaat = true;
              if ( route (i1+1, j1, code, kleur) )
                {
                cell_array[i1][j1].zuid = true;
                cell_array[i1+1][j1].noord = true;
                }
                // break;
              }
            }
          }
        // nieuwe route = andere kleur
        if ( route_bestaat == false ) { route (i, j, code, kleur); }
        }
      }
      // sluit routes onderling aan
      // bouw de route_codes lijst op
      //  route_codes.clear(); methode niet overal bekend
      // i = 0;
      while ( route_codes.isEmpty() == false )
        {
        route_codes.remove(route_codes.lastElement());
        }

      for (i=0 ; i <= 19 ; i++ )
        {
        for (j=0 ; j <= 19 ; j++)
          {
          if ( route_codes.contains(cell_array[i][j].route_code) == false )
            {
            route_codes.addElement( cell_array[i][j].route_code);
            // aansluiting op VOORGAANDE route
            // nog niet op alle routes; dus VIA routes
            if (j>0)
              {
              cell_array[i][j].west = true;
              cell_array[i][j-1].oost = true;
              }else{
                if (j < endY) {
                    cell_array[i][j].oost = true;
                    cell_array[i][j+1].west = true;
                }
            }
            }
          }
        }
      
            
      
      return code;
   }

    public boolean route(int i,int j,String code, Color kleur)
    {
    int k;
    int r_index = 0;
    String r;
    double rd;
    Vector nzow = new Vector();
    String el;
    boolean poort = false;

    // bepaal random volgende cel N,Z,O,W
    // bepaal richting

    if ( i < cell_array.length && j < cell_array[0].length && cell_array[i][j].used == false)
      {
      //
      cell_array[i][j].used = true;
      cell_array[i][j].route_code = code;
      cell_array[i][j].kleur = kleur;

      // vul vector nzow Enumeration
      nzow.addElement ("N");
      nzow.addElement ("Z");
      nzow.addElement ("O");
      nzow.addElement ("W");

      // set nzow bepaling
      
      // NOORD = ri 4
      if ( i <= 0 ) {
      for (k=0 ; k < nzow.size(); k++) {
        if ( (String) nzow.elementAt(k) == "N" )
          {
          nzow.removeElementAt(k);
          // return false;
          break;
          }
        }
        
      }
      
      // ZUID = ri 3
      if ( i > 18 ) {
      for (k=0 ; k < nzow.size();k++) {
        if (( String) nzow.elementAt (k) == "Z" )
          {
          nzow.removeElementAt(k);
          // return false;
          break;
          }
        }
        
      }
      
        // OOST = ri 2
      if ( j > 18 ) {
      for (k=0 ; k < nzow.size(); k++) {
        if ( (String) nzow.elementAt(k) == "O" )
          {
          nzow.removeElementAt(k);
          // return false;
          break;
          }
        }
      }


      // WEST = ri 1
      if ( j <= 0 ) {
      for (k=0 ; k < nzow.size(); k++) {
        if ( (String) nzow.elementAt(k) == "W" )
          {
          nzow.removeElementAt(k);
          
          // return false;
          break;
          }
        }
      }

    
    
      

      // selectie beperking
      for (k=0 ; k < nzow.size(); k++) {
        if ( (String) nzow.elementAt(k) == "N" && cell_array[i-1][j].used == true)
          {
          nzow.removeElementAt(k);
          } else {
        if ( (String) nzow.elementAt(k) == "Z" && cell_array[i+1][j].used == true)
          {
          nzow.removeElementAt(k);
          } else {
        if ( (String) nzow.elementAt(k) == "O" && cell_array[i][j+1].used == true)
          {
          nzow.removeElementAt(k);
          } else {
        if ( (String) nzow.elementAt(k) == "W" && cell_array[i][j-1].used == true)
          {
          nzow.removeElementAt(k);
          } } } }
      }

      // foreach ..
      while ( nzow.size() > 0 && poort == false )
        {
        r_index = (int) ( Math.round(Math.random() * (nzow.size() -1) ) );
        r = (String) nzow.elementAt(r_index);

        // om zeker te zijn dat ie stopt
        // poort =true;

          if ( r == "N" && route(i-1,j,code, kleur) )
                  {
                  cell_array[i][j].noord = true;
                  cell_array[i-1][j].zuid = true;
                  nzow.removeElementAt(r_index);
                  poort = true;
                  } else {
          if ( r == "Z" && route(i+1,j,code, kleur) )
                  {
                  cell_array[i][j].zuid = true;
                  cell_array[i+1][j].noord = true;
                  nzow.removeElementAt(r_index);
                  poort =true;
                  } else {
          if ( r == "O" && route(i,j+1,code, kleur) )
                  {
                  cell_array[i][j].oost = true;
                  cell_array[i][j+1].west = true;
                  nzow.removeElementAt(r_index);
                  poort=true;
                  } else {
          if ( r == "W" && route(i,j-1,code, kleur) )
                  {
                  cell_array[i][j].west = true;
                  cell_array[i][j-1].oost = true;
                  nzow.removeElementAt(r_index);
                  poort =true;
                  }else { 
                poort=true;
               }}}}
        } // while
      return poort;
      // if
      } else {
      
      return false;
      }
    }


  public Color random_kleur ()
  {
  double x,y;
  int l, c;
  l = kleuren.length ;
  do {
    x = Math.random();
    y = Math.round( (l-1) * x );
    c = (int) y ;
    }
  while ( kleuren[c] == Color.black );
  return kleuren[c];
  
  }


  public void paint ( Graphics y )
  {
      super.paint(y);
 
    Graphics2D g2D = (Graphics2D) y;      
 
    g2D.setStroke(new BasicStroke(2F));  // set stroke width of 2

 // int x_off = 40; 2016
 // int y_off = 40;
  int i,j;
  int r;
  int step = 10 ;
  int t=1;
  String code;

  // drawString font
  y.setFont(klein);
  
  
  
  // x-ingave maal random of oneindig bij negatieve ingave
  while ( t<=x || x<0 )
  {
  
  // bereken het doolhof
  doolhof();
  
  
  // initialiseer();
  

  for (i = 0 ; i < cell_array.length ; i++)
    {
    for (j=0 ; j < cell_array[0].length ; j++) {

        if ( cell_array[i][j].used ) {

          
          y.setColor( cell_array[i][j].kleur );
          y.fillRect(x_off + cell_array[i][j].x1, y_off + cell_array[i][j].y1, cell_array[i][j].breedte, cell_array[i][j].hoogte);

          // teken hekken
          y.setColor( Color.black );
          y.drawRect(x_off + cell_array[i][j].x1, y_off + cell_array[i][j].y1, cell_array[i][j].breedte, cell_array[i][j].hoogte);

          // teken de poorten
          y.setColor( cell_array[i][j].kleur );
          if ( cell_array[i][j].zuid )
          {
          y.drawLine(x_off + cell_array[i][j].x1, y_off + cell_array[i][j].y2 , x_off + cell_array[i][j].x2 ,y_off + cell_array[i][j].y2 );
          }

          if ( cell_array[i][j].noord )
          
          {
          y.drawLine(x_off + cell_array[i][j].x1, y_off + cell_array[i][j].y1 , x_off + cell_array[i][j].x2 ,y_off + cell_array[i][j].y1 );
          }

          if ( cell_array[i][j].oost  )
          {
          y.drawLine(x_off + cell_array[i][j].x2, y_off + cell_array[i][j].y1 , x_off + cell_array[i][j].x2 ,y_off + cell_array[i][j].y2 );
          }

          if ( cell_array[i][j].west )
          {
          y.drawLine(x_off + cell_array[i][j].x1, y_off + cell_array[i][j].y1 , x_off + cell_array[i][j].x1 ,y_off + cell_array[i][j].y2 );
          }
          
          }
       } // end for2
    } // end for1

  // schrijf routes

  y.setFont(mono);

  y.setColor( Color.black);
/* solver routes */

  y.fillRect(x_off + 520, y_off + 10 , 100, 240 );
  for (i=0 ; i <= route_codes.indexOf( route_codes.lastElement() ) ; i++ )
    {
    y.setColor(route_kleur(route_codes.elementAt(i).toString() ) );
    y.fillRect(x_off + 520, y_off + 10  + ( i * 12 ), 10, 10 );
    
    y.setColor( Color.white );
    y.drawString(route_codes.elementAt(i).toString() , x_off + 540, y_off + 20 +( i * 12 ));
    }

  // schrijf aantal gemaakte doolhoven
  t2.setText(" " + t);
  t++;
  
  
  // repaint();  // repeat paint methode
  } // end while

  y.setColor( Color.BLUE );
  y.drawString(" K.Bakker (2016) Doolhof v2016.1 " , x_off , this.Windowheight - y_off );
  
  // solveMaze and write ...
  solveMaze(y);
 
  
  } // end paint

  public Color route_kleur (String code)
  {
  Color kleur = Color.black;

  for (int i = 0 ; i < cell_array.length || kleur==Color.black; i++)
    {
    for (int j=0 ; j< cell_array[0].length ; j++)
      {
      if ( cell_array[i][j].route_code == code)
        {
        kleur = cell_array[i][j].kleur;
        break;
        }
      }
    }
    return kleur;
  }
  
  
    
public void generateMaze() {
        
    for (int i=0; i< cell_array.length; i++) {
        for (int j=0; j< cell_array.length; j++) {
            cell_array[i][j].route = -1;
            if ( CountGate(i,j) > 0 ) cell_array[i][j].route = 999;
             
                        
        }
    }
 }


public void solveMaze(Graphics y) {

    startX = 0;
    startY = 0;
    
    generateMaze(); 

    // verwijder eerst de doodlopende straten tot een T-splitsing
    
    
    
    for (int row = 0; row < cell_array.length; row++)  
        // Sets boolean Arrays to default values
        for (int col = 0; col < cell_array.length; col++){
          
            cell_array[row][col].correctpath = false;
            cell_array[row][col].route = -1;
            
        }
    
    RemoveDeadEnd();
    
    boolean b = recursiveSolve(startX, startY,0);
    
    
    // Clean();
    
    showMazeSolution(y);
    
}

public void showMazeSolution(Graphics y) {
   
    String imageFileName = "santaclause.jpg";
    /*
    URL imageSrc = null;
        try {
             imageSrc = ((new File(imageFileName)).toURI()).toURL();
        } catch (MalformedURLException e) {}
    BufferedImage img;
        try {
            img = ImageIO.read(imageSrc);
        } catch (IOException ex) {
            Logger.getLogger(doolhofv1.class.getName()).log(Level.SEVERE, null, ex);
        }
*/
     for (int row = 0; row <= endX ; row++)  
        // Sets boolean Arrays to default values
        for (int col = 0; col <= endY; col++){
            
            if (   cell_array[row][col].correctpath )  {
        
                y.setColor( Color.WHITE );
                
                
                y.fillOval(x_off + cell_array[row][col].x1 + cell_array[row][col].breedte / 4, y_off + cell_array[row][col].y1 + cell_array[row][col].hoogte /4,cell_array[row][col].breedte / 2,cell_array[row][col].hoogte /2  );
                // y.drawString( String.valueOf(maze[row][col]) , x_off + cell_array[row][col].x1 + cell_array[row][col].breedte / 2 , y_off + cell_array[row][col].y1 + cell_array[row][col].hoogte /2);
                
                // y.drawImage( img , x_off + cell_array[row][col].x1 + cell_array[row][col].breedte / 4, y_off + cell_array[row][col].y1 + cell_array[row][col].hoogte /4, rootPane);
              
                
            }
            
        }
    
}

public boolean recursiveSolve(int x, int y,int RouteNr) {
    
   // test
   int Route = RouteNr;
   
   
    // System.out.println("R " + dir + " =  R " + x + "C " + y + " Route " + RouteNr);
    // If you reached the end  
    if (x == endX && y == endY) { 
        System.out.println("China , We reached it");
        cell_array[x][y].correctpath = true;
        cell_array[x][y].route = Route;
        return true;
    }
    
    
    // afgesloten paden = 99 en nieuwe paden != -1
    if (cell_array[x][y].route == 99 || cell_array[x][y].route != -1 )return false;  
    
    // doodlopend pad als geen andere richting meer dan de looprichting <- = W , -> = O
    
      
     
     if (CountGate(x,y) <= 0) {
        cell_array[x][y].correctpath = false;
        cell_array[x][y].route = 99;
        Reverse(x,y, Route);
     }else{
        cell_array[x][y].route = Route;  // het behoort tot de geldige paden
        cell_array[x][y].correctpath = true;
        
     }
     
  
     
    // zoek verder langs het pad
    
       
    if (( CountGate(x,y)>0)  ) { 
                        if (cell_array[x][y].noord && (x > 0)  ) {
     
                            if (CountGate(x,y) > 2  ) Route++;
                            recursiveSolve(x-1,y, Route);
                        }
                        if (cell_array[x][y].zuid && (x < height )  ) {
                            if (CountGate(x,y) > 2  ) Route++;
     
                            recursiveSolve(x+1,y, Route);
                        }
   
                        if ( cell_array[x][y].oost && (y < width ) ) {  // je kunt naar OOST en NIET buiten rand
                            if (CountGate(x,y) > 2  ) Route++;
     
                            recursiveSolve(x,y+1,Route); // controleer op DEADEND
                            
                        }
                        if ( cell_array[x][y].west && (y > 0) ) {
                            if (CountGate(x,y) > 2  ) Route++;
     
                            recursiveSolve(x,y-1,Route);                       
                        }                                                    
    }
    
   
    return cell_array[x][y].correctpath;
    
    

}


public void ReverseT(int x, int y, int Route) {
    // maak een recursief dat uitzoekt wat er doodlopend is en laat dat uitvallen mt code 99
    // voorbewerking voor routeSolver()
    // route teruglopen tot dat een cell meer dan 2 aansluitingen heeft
    // straten moeten opgeruimd worden tot de splitsing
  
    int C = 0;
    boolean DelRoute=true;
    boolean step=false;
      
    
    
    while ( DelRoute) {
        
        step = false;
        
        System.out.println("ReverseT in op " + x + "-" + y);
        if ( cell_array[x][y].noord && (x>0) && !step) {
             if ( cell_array[x-1][y].route == Route) 
                {
                        x--;
                        step=true;
                        
                }
                         
        }
        
        if ( cell_array[x][y].zuid &&(x<endX) && !step) {
             if ( cell_array[x+1][y].route == Route) 
                {
                    x++;
                    step = true;
                }
        }
           
        if ( cell_array[x][y].oost && (y<endY && !step) ) {
            if ( cell_array[x][y+1].route == Route) 
                {
                    y++;
                    step = true;
                    
                }
        }
        if ( cell_array[x][y].west && (y>0) && !step) {
            if ( cell_array[x][y-1].route == Route) 
                {
                    y--;
                    step = true;
                    
                }
        }
        
        // volgens Route verwijderen, stoppen bij beginpunt en eindpunt (0,0) en (19,19)
        if ( cell_array[x][y].route == Route && CountGate(x,y) < 3 && !(x==endX && y==endY) && !(x==0 && y==0) ) {
            cell_array[x][y].correctpath = false;
            cell_array[x][y].route = 99;
            System.out.println("Route "+ Route + " op " + x + "-" + y + " gates " + CountGate(x,y) );
            // System.out.println("Reverse Route " + Route);
        }   else {
            DelRoute = false;
            System.out.println("Einde Route op " + x + "-" + y + " gates " + CountGate(x,y) + " op Route " + Route);
        }
        if ( C++ > 99999) DelRoute = false;
        }
        
}


public void Reverse(int x, int y, int Route) {
    // maak een recursief dat uitzoekt wat er doodlopend is en laat dat uitvallen mt code 99
    // voorbewerking voor routeSolver()
    // route teruglopen tot dat een cell meer dan 2 aansluitingen heeft
    // straten moeten opgeruimd worden tot de splitsing
  
    int C = 0;
    boolean DelRoute=true;
    boolean step=false;
      
    
    
    while ( DelRoute) {
        
        step = false;
        
        
        if ( cell_array[x][y].noord && (x>0) && !step) {
             if ( cell_array[x-1][y].route == Route) 
                {
                        x--;
                        step=true;
                        
                }
                         
        }
        
        if ( cell_array[x][y].zuid &&(x<endX) && !step) {
             if ( cell_array[x+1][y].route == Route) 
                {
                    x++;
                    step = true;
                }
        }
           
        if ( cell_array[x][y].oost && (y<endY && !step) ) {
            if ( cell_array[x][y+1].route == Route) 
                {
                    y++;
                    step = true;
                    
                }
        }
        if ( cell_array[x][y].west && (y>0) && !step) {
            if ( cell_array[x][y-1].route == Route) 
                {
                    y--;
                    step = true;
                    
                }
        }
        
        // volgens Route verwijderen
        if ( cell_array[x][y].route == Route) {
            cell_array[x][y].correctpath = false;
            cell_array[x][y].route=99;
            // System.out.println("Reverse Route " + Route);
        }else{
                    DelRoute = false;
                    // Route is uitgeput, nu verder ?
                    // indien andere tak is ook 99 doodlopend
                    // neem het volgende knooppunt mee met weer een step
                    // zoek volgende knooppunt en ga verder
                    if ( cell_array[x][y].noord && x > 0 ) {
                        if ( CountRoute(x-1,y,99) > 1 ) {
                        x--;
                        Route = cell_array[x][y].route;
                        System.out.println("Reverse Route " + Route);
                        DelRoute = true;
                        }
                    }
                    if ( cell_array[x][y].zuid && x < endX ) {
                        if ( CountRoute(x+1,y,99) > 1 ) {
                        x++;
                        Route = cell_array[x][y].route;
                        System.out.println("Reverse Route " + Route);
                        DelRoute = true;
                        }
                    }
                    if ( cell_array[x][y].oost && y < endY ) {
                        if ( CountRoute(x,y+1,99) > 1 ) {
                        y++;
                        Route = cell_array[x][y].route;
                        
                        System.out.println("Reverse Route " + Route);
                        DelRoute = true;
                        }
                    }
                    if ( cell_array[x][y].west && y > 0 ) {
                        if ( CountRoute(x,y-1,99) > 1 ) {
                        y--;
                        Route = cell_array[x][y].route;
                        
                        System.out.println("Reverse Route " + Route);
                        DelRoute = true;
                        }
                    }
                        
                
            }
            if ( C++ > 99999) DelRoute = false;
        }
        
       
        
    
    
    
}

public int CountGate(int row, int col) {
    int Count = 0;
    if (cell_array[row][col].noord) Count++;
    if (cell_array[row][col].zuid) Count++;
    if (cell_array[row][col].oost) Count++;
    if (cell_array[row][col].west) Count++;
    
    
    
    return Count;
}


public int CountRoute(int row, int col, int Route) {
    // iets is verkeerd hier ..
    int Count = 0;
    
    
    if (row > 0) {
    
        if ( cell_array[row][col].noord && cell_array[row-1][col].route == Route ) {
            Count++;
        }
    }
    if (row<endX) {
        
        if ( cell_array[row][col].zuid && cell_array[row+1][col].route == Route ) {
            Count++;
            
        }
    }
    if (col<endY) {
       
        if ( cell_array[row][col].oost && cell_array[row][col+1].route == Route ) {
            Count++;
        }
    }
    if (col > 0) {
        if ( cell_array[row][col].west && cell_array[row][col-1].route == Route ) {
            Count++;
        }
    }
   
    
    
    return Count;
}


public void Clean() {
    // ruim de DEADENDS op
    
    boolean Herhaal = true;
    
    while ( Herhaal) {
    
        Herhaal = false;
        
        for (int x = 0; x <= endX; x ++) {
            for (int y = 0 ; y<= endY ; y++) {
                if ( (x != 0 || y != 0 ) && ( y != endY || x != endX)  &&  cell_array[x][y].route != 99 && cell_array[x][y].route != -1 )  {


                    if ( CountRoute(x,y,99) > 1) {
                        
                        System.out.println("Clean op " + cell_array[x][y].route + " op " + x + "-" + y  );
                        Reverse(x,y, cell_array[x][y].route );
                        cell_array[x][y].correctpath = false;
                        cell_array[x][y].route = 99;
                        
                        Herhaal = true;

                    } 

                }
            }

        }
    }
}
    

public void RemoveDeadEnd() {
    // ruim de DEADENDS op
    
   boolean Herhaal = true;
   int Route;
   
   while ( Herhaal) {
       
       Herhaal = false;
   
    
    
        for (int x = 0; x <= endX; x ++) {
            for (int y = 0 ; y <= endY ; y++) {
                if ( (x != 0 || y != 0 ) && ( y != endY || x != endX) )  {

                    // DEADEND heeft maar 1 aansluiting

                    if (CountGate(x,y) <=1 && cell_array[x][y].route != 99 ) {
                        System.out.println("DeadEnd op " + x + "-" + y);
                        // heen en terug..
                        Route = cell_array[x][y].route; // meestal -1
                        
                        cell_array[x][y].route = 99;
                        ReverseT(x,y,Route);
                        
                        Herhaal = true;
                    }

                    // zit al in Reverse
                    // Ook de wegen met 2 of meer aansluitingen die doodlopend zijn
                    if ( CountRoute(x,y,99) > 1 && cell_array[x][y].route != 99 ) {
                        System.out.println("DeadEnd remove op 2 x 99 " + x + "-" + y);
                        Route = cell_array[x][y].route; // meestal -1
                        cell_array[x][y].route = 99;
                        ReverseT(x,y,Route);
                        
                        Herhaal = true;
                    }

                }
            }

        }
   }
}
    



}


